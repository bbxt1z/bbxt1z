/*
 * Course:    TCSS142 - Introduction to Object-Oriented Programming
 * File Name:  Project4.java
 * Assignment: 4
 * Due Date:   08/13/2024
 * Instructor: Mr. Schuessler 
 */
public class TestGrades {
   private static int myCount = 0;
   private String myFN;
   private String myLN;
   private int[] myGrades;
   private int[] theGrades;
/**
 * Based on information received from the input file in in 
 * Tandem with the GradeDriver program,
 * This program will create an array from the output file 
 * And calculates the averages of each student based on their test scores
 * And calculates the highest, lowest, and overall averages.
 *
 * @author Breanna Battle
 * @version 2020 April 12
 */


/**
 * The TestGrades Method is responsible for taking in information and organizing it
 * within an array
 *
 * @param theFN receives a string and reads the student's first name
 * @param theFN receives a string and reads the student's last name
 * @param theGrades receives an integer array and places the grades within the array
 * @param myCount receives an integer that determines the amount of students 
 */

  public TestGrades(String theFN, String theLN, int[] theGrades, int myCount) {
   myFN = theFN;
   myLN = theLN;
   myGrades = new int[theGrades.length];
   for(int i = 0; i < myGrades.length; i++) {
        myGrades[i] = theGrades[i];
     }
     myCount++;
  }
  public int getStudentCount() {
      return myCount;
  }
  public String getFirstName() {
      return myFN;
  }
  public String getLastName() {
      return myLN;
/**
 * The getTestAverage Method is responsible for calculating the overall grades average
 * 
 * @return returns the calculated average  
 */
  }
  public int getTestAverage() {
   int small = myGrades[0];
   double ToT = small;
   for(int i = 1; i < myGrades.length; i++) {
      ToT += myGrades[i];
      if(myGrades[i] < small) {
         small = myGrades[i];
         } 
      }
      return (int) Math.round((ToT - small) / (myGrades.length - 1));   
/**
 * The setScore Method is responsible for determining whether or 
 * not the test scores entered are valid
 *
 * @param theIndex receives an int and ensures the test scors received 
 * are the same length as the array
 * @param theTestScore receives an int that sets the testscores within the array
 */
  }
  public void setScore(int theIndex, int theTestScore) {
   if(theIndex > 0 && theIndex < 5 && theTestScore <= 100 && theTestScore >= 0) {
      myGrades[theIndex - 1] = theTestScore;
  } else {
      throw new IllegalArgumentException("Invalid Test Score");
     }
/**
 * The toString Method is responsible for converting the received information
 * into strings 
 *
 * @return returns the converted strings 
 */

  }
  public String toString() {
   String result = "";
   result += myFN + " " + myLN + " [" + myGrades[0] + "," + myGrades[1]
             + "," + myGrades[2] + "," + myGrades[3] + "] " + "Average = "
             +getTestAverage();
     return result;
   }
}