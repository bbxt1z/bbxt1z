/*
 * Course:    TCSS142 - Introduction to Object-Oriented Programming
 * File Name:  Project4.java
 * Assignment: 4
 * Due Date:   08/13/2024
 * Instructor: Mr. Schuessler 
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Scanner;
/**
 * Based on information received from the input file,
 * This program will create an array from the output file 
 * And calculates the averages of each student based on their test scores
 * And calculates the highest, lowest, and overall averages.
 *
 * @author Breanna Battle
 * @version 2020 April 12
 */
public class GradeDriver{
    private static int myCount = 0;
         private String myFN;
         private String myLN;
         private int[] myGrades;
         private int[] theGrades;

   public static void main(String[] theArgs){
     	Scanner input = null;
     	PrintStream output = null;
       try {
         input = new Scanner(new File("in4.txt"));
     		output = new PrintStream(new File("out4.txt"));
      }
      catch (FileNotFoundException e) {
         System.out.println("Error opening file: " + e);
   }
   TestGrades[] grades = getGrades(input);
   report(grades, output);
   highestAve(grades, output);
   lowestAve(grades, output);
   overallAve(grades, output);
   input.close();
   output.close();
   }     
/**
 * The TestGrades Method is responsible for creating an array   
 * Containing the grades/test scores of each student 
 *
 * @param theR receives a scanner containg the results
 * of each student's grades.
 * 
 * @return returns the grades array
 */
   public static TestGrades[] getGrades(Scanner theR) {
      int totalStudents = theR.nextInt();
      TestGrades[] grades = new TestGrades[totalStudents];
      for(int i = 0; i < totalStudents; i++) {
         String theFN = theR.next();
         String theLN = theR.next();
         int[] theGrades = new int[4];
            for(int j = 0; j <= 3; j++) {
               theGrades[j] = theR.nextInt();
          }
          grades[i] = new TestGrades(theFN, theLN, theGrades, myCount);
       }
       return grades; 
/**
 * The report Method is responsible for calculating 
 * the total number of students based on the input file  
 *
 * @param theG receives the TestGrades array and places the grades inside
 * @param theO receives a PrintStream 
 */
    }
    public static void report(TestGrades[] theG, PrintStream theO) {
      theO.println("Total number of students: " + theG.length);
      for(int i = 0; i < theG.length; i++) {
         theO.println(theG[i].toString());
      }
   }
/**
 * The highestAve Method is responsible for calculating the highest average   
 * 
 * @param theG receives the TestGrades array and places the grades inside
 * @param theO receives a PrintStream 
 */
   public static void highestAve(TestGrades[] theG, PrintStream theO) {
      int result = 0;
      for(int i = 0; i < theG.length; i++) {
         if(theG[i].getTestAverage() > result) {
            result = theG[i].getTestAverage();
         }
      }
      theO.println("");
      theO.println("The Highest Average = " + result);
/**
 * The lowestAve Method is responsible for calculating the lowest average
 *
 * @param theG receives the TestGrades array and places the grades inside
 * @param theO receives a PrintStream 
 */
   }
   public static void lowestAve(TestGrades[] theG, PrintStream theO) {
      int result = 101; 
      for(int i = 0; i < theG.length; i++) {
         if(theG[i].getTestAverage() < result) {
            result = theG[i].getTestAverage();
         }
      }
      theO.println("The Lowest Average = " + result);
/**
 * The overallAve Method is responsible for calculating the overall class average
 *
 * @param theG receives the TestGrades array and places the grades inside
 * @param theO receives a PrintStream 
 */
   }
   public static void overallAve(TestGrades[] theG, PrintStream theO) {
      double result = 0;
      for(int i = 0; i < theG.length; i++) {
         result += (double)theG[i].getTestAverage();
      }
      result = result / theG.length;
      theO.println("The Overall Average = " + Math.round(result));
   }
}